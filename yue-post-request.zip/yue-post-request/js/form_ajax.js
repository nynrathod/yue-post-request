/* global wp, jQuery */
/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function( $ ) {
	
	$('.myalert').hide();
	jQuery.validator.setDefaults({
		debug: true,
		success: "valid"
	});
	$( "#iform" ).validate({
		rules: {
			iname: {
				required: true,
				lettersonly: true
			},
			iemail: {
				required: true,
				email: true
			},
			ptitle: {
				required: true,
				maxlength: 100
			},
			pcontent: {
				required: true,
				maxlength: 300
			}
		},
	});
	jQuery.validator.addMethod('lettersonly', function(value, element) {
		return this.optional(element) || /^[a-z áãâäàéêëèíîïìóõôöòúûüùçñ]+$/i.test(value);
	}, "Only Alphabetical charecter allowed");
	
		$('form.ajax').on('submit', function(e){
			e.preventDefault();
			var iname = $('#iname').val();
			var iemail = $('#iemail').val();
			var ptitle = $('#ptitle').val();
			var pcontent = $('#pcontent').val();

			$.post('https://yuezers.com/wingify/wp-admin/admin-ajax.php', {
				action:'yue_post_insert', 
				iname: iname,
				iemail: iemail,
				ptitle: ptitle,
				pcontent: pcontent,
				type: 'POST',
			}, function(response) {
				if(response == 1) { 
					$('.myalert').show(); 
				} else { 
					$('.error_block')[0].innerhtml = response; 
// 					$('.myalert').hide();
				}
			});
		});

}( jQuery ) );
