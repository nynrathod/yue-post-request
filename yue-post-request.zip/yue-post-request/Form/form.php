<?php

function yue_post_form() { ?>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form id="iform" method="post" class="ajax">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<div class="alert alert-success alert-dismissible myalert" role="alert">
						Form Submitted Successfully
						<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
					</div>
					<div class="form-floating mb-3">
						<input type="text" class="form-control" id="iname" name="iname" placeholder="Enter Name">
						<label for="iname" class="form-label">Your Name</label>
					</div>
					<div class="form-floating mb-3">
						<input type="email" class="form-control" id="iemail" name="iemail" placeholder="name@example.com">
						<label for="iemail" class="form-label">Email address</label>
					</div>
					<div class="form-floating mb-3">
						<input type="text" class="form-control" id="ptitle" name="ptitle" placeholder="Post Title">
						<label for="ptitle" class="form-label">Post Title</label>
					</div>
					<div class="form-floating mb-3">
						<textarea class="form-control" id="pcontent" name="pcontent" placeholder="Enter Post Description" style="height: 100px"></textarea>
						<label for="pcontent" class="form-label">Post Content</label>
					</div>
				</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary postbtn">Save changes</button>
				<div class="row d-block error_block" style="width: 100%;">
					<div class="col-12">
						
					</div>
				</div>
			</div>
			</form>
	</div>
</div>
</div>

<?php }

add_action('wp_head', 'yue_post_form');