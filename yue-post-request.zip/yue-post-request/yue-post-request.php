<?php
/*
 * Plugin Name: YUE Post Request
 * Plugin URI: https://YUEzers.com
 * Version: 1.0
 * Author: Nayan Rathod
 * Author URI: https://YUEzers.com
 * License: GPL2
 *
 * @package YUE-Post-Request
 * @copyright Copyright (c) 2022, Nayan Rathod
 * @license GPL2+
*/

if (!defined('YUE_PLUGIN_DIR')) {
	define('YUE_PLUGIN_DIR',plugins_url('', __FILE__));
}

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

if (!class_exists('YUE_Post_Request')) {

	class YUE_Post_Request {

		protected static $yue_instance;
		
		// Append Button for form 		
		function __construct() {
			add_filter( 'wp_nav_menu_items', 'your_custom_menu_item', 10, 2 );
			function your_custom_menu_item ( $items, $args ) {
				if ( $args->menu  == 'Main Menu') {
					$items .= '<li><a class="nav-link"><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">   Launch demo modal </button></a></li>';
				}
				return $items;
			}
        }
		
		// Performing Post Submitting		
		function yue_post_insert() {
			
			$name = sanitize_text_field( $_POST['iname'] );
			$email = sanitize_email($_POST['iemail']);
			$post_title = sanitize_text_field($_POST['ptitle']);
			$post_content = sanitize_textarea_field($_POST['pcontent']);
			

			// Do some minor form validation to make sure there is content
			if (strlen($_POST['ptitle']) > 100) {
				echo 'Title Should not be greater than 100 character';
				wp_die();
			}
			if (strlen($_POST['pcontent']) > 300) {
				echo 'Content Should not be greater than 100 character';
				wp_die();
			}
			
			$username = $name.'_wingsify';
			$password = wp_generate_password(12, true, false);

			$udata = array(
				'user_login' => $username,
				'first_name' => $name,
				'user_email' => $email,
				'password'   => $password
			);
			if (username_exists($username) == null && email_exists($email) == false) {
				$user_id = wp_insert_user($udata);
			} else {
				$user = get_user_by( 'email', $email );
				$user_id = $user->ID;
			}
						
			$post = array(
				'post_title'    => $_POST['ptitle'],
				'post_content'  => $_POST['pcontent'],
				'post_category' => array(50), 
				'post_status'   => 'draft',   // Could be: publish
				'post_type' 	=> 'post', // Could be: `page` or your CPT
				'post_author'   => $user_id
			);
			if(wp_insert_post($post)) {
				echo true;
				$to = 'nayanrathod23@gmail.com';
				$subject = 'The subject';
				$body = 'The email body content';
				$headers = array('Content-Type: text/html; charset=UTF-8');

				wp_mail( $to, $subject, $body, $headers );
				wp_die();
			} else {
				echo false;
				wp_die();
			}
			
			wp_die();
		}


		// Callig Post Funtion 		
		function init() {
			add_action( 'wp_enqueue_scripts',  array($this, 'yue_load_front'));
			add_action( 'wp_ajax_yue_post_insert', array($this,'yue_post_insert' ));
			add_action( 'wp_ajax_nopriv_yue_post_insert', array($this,'yue_post_insert' ));
		}
		
		// Including Require JS and CSS	
		function yue_load_front() {
			wp_enqueue_style( 'yue_front_style', YUE_PLUGIN_DIR . '/css/custom.css', false, '1.0.0' );
			wp_enqueue_script( 'jqueryvalidate','https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js', array('myjquery'), _S_VERSION, true  );
			wp_enqueue_script( 'jqueryvalidateadditional','https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js', array('myjquery'), _S_VERSION, true  );
			wp_enqueue_script( 'yue_front_script2', YUE_PLUGIN_DIR . '/js/form_ajax.js', array('jqueryvalidate'), _S_VERSION, true );
			//             wp_localize_script( 'yue_front_script1', 'yue_ajax_postajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
		}

		// Include Post Form
		function includes() {
			include_once('Form/form.php');
		}

		public static function yue_instance() {
			if (!isset(self::$yue_instance)) {
				self::$yue_instance = new self();
				self::$yue_instance->init();
				self::$yue_instance->includes();
			}
			return self::$yue_instance;
		}


	}

	// PHP Mailer Configuration	
	add_action('plugins_loaded', array('YUE_Post_Request', 'yue_instance'));
	add_action( 'phpmailer_init', 'send_smtp_email' );
		function send_smtp_email( $phpmailer ) {
			$phpmailer->isSMTP();
			$phpmailer->Host       = SMTP_HOST;
			$phpmailer->SMTPAuth   = SMTP_AUTH;
			$phpmailer->Port       = SMTP_PORT;
			$phpmailer->SMTPSecure = SMTP_SECURE;
			$phpmailer->Username   = SMTP_USERNAME;
			$phpmailer->Password   = SMTP_PASSWORD;
			$phpmailer->From       = SMTP_FROM;
			$phpmailer->FromName   = SMTP_FROMNAME;
		}
}